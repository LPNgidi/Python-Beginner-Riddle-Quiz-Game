class QandA:


    def __init__(self,the_questions,the_answers):
        self.the_questions=the_questions
        self.the_answers=the_answers
    
    
    



    