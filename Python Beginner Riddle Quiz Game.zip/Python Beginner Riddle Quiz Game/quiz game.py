'''Python Beginner Project: MCQ Riddle Quiz Game by Lungile Pamela Ngidi:
This MCQ game will ask the user riddle questions and print out the points that the user scored for the correct answers at the end, 
if the user enters the wrong answer they'll be shown the correct answer. The user also has the option of playing again,
when the user chooses to replay the riddles are shuffled.'''
from quizgameQandA import QandA
from random import shuffle
UserName=input("Please Enter Your Name:\n").strip()


questions=["What has to be broken before you can use it?\nA. a leg\nB. an egg\nC. a cup\nD. an evelope\n",
    "I’m tall when I’m young, and I’m short when I’m old. What am I?\nA. A human\nB. a dog\nC. a candle\nD. candy\n ",
    "What month of the year has 28 days?\nA. February\nB. July\nC. March\nD. All Of Them\n",
    "What is full of holes but still holds water?\nA. a bucket\nB. a sponge\nC. a cup\nD. uh...the ocean?\n" ,
    "What question can you never answer yes to?\nA. when will we reach our destination?\nB.how old are you?\nC.when will you visit me?\nD. are you asleep yet?\n"]

riddles=[
    QandA(questions[0],"B".casefold()),
    QandA(questions[1],"C".casefold()),
    QandA(questions[2],"D".casefold()),
    QandA(questions[3],"B".casefold()),
    QandA(questions[4],"D".casefold())]
shuffle(riddles)
def play(riddles):
    score=0
    for question in riddles:
        answer=input(question.the_questions).casefold().strip()
        if answer==question.the_answers:
            score=score+1
        if answer!=question.the_answers:
            print(f"the correct answer is {question.the_answers.upper()}")
    print(f"{UserName} you got {score}/{len(questions)} correct!")

    
def validateAndExecute():

    playing=input("Do You Want to Play?:\n").strip()
    try:
        while playing in ("Y","y","yes","YES","Yes"):

            print(f"Helllo {UserName}, Welcome to the Riddle Quiz Game!")
            play(riddles)
            replay=input("would you like to play again?\n").strip()
            if replay in ("Y","y","yes","YES","Yes"):
                 print(f"Welcome back to the Riddle Quiz Game {UserName}!")
                 play(riddles)
                 exit()
            elif replay in ("n","N","NO","No","no"):
                print(f"Aww goodbye {UserName}, I hope you can play with me again sometime")
                exit()
            else: raise ValueError
       
            break
        if playing in ("n","N","NO","No","no"):
            print(f"Too bad, I would've loved the opportunity to play with you {UserName}")
            
        else: raise ValueError
    except ValueError:
        print("Uh Oh, it looks like you have entered an invalid value")
 


validateAndExecute()







    

    

    






